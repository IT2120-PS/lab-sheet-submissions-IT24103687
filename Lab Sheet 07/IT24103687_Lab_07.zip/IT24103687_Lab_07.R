
setwd("C:\\Users\\risad\\OneDrive\\Desktop\\Edu\\_Year 2 Sem 1\\PS\\Labs")
getwd()

# Q1: Uniform Distribution
a <- 0
b <- 40
prob_train <- punif(25, min = a, max = b) - punif(10, min = a, max = b)
cat(sprintf("Q1: Probability train arrives between 8:10 and 8:25 = %.4f\n", prob_train))

# Q2: Exponential Distribution
lambda <- 1 / 3
prob_update <- pexp(2, rate = lambda)
cat(sprintf("Q2: Probability update takes at most 2 hours = %.4f\n", prob_update))

# Q3: Normal Distribution
mean_iq <- 100
sd_iq <- 15

# i) P(IQ > 130)
prob_above_130 <- 1 - pnorm(130, mean = mean_iq, sd = sd_iq)
cat(sprintf("Q3.i: Probability that IQ > 130 = %.4f\n", prob_above_130))

# ii) 95th percentile
iq_95th <- qnorm(0.95, mean = mean_iq, sd = sd_iq)
cat(sprintf("Q3.ii: 95th percentile IQ score = %.2f\n", iq_95th))

