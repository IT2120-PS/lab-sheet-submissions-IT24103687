setwd("C:\\Users\\risad\\OneDrive\\Desktop\\IT24103687")


#fixes random number generator
#sets fixed randomness
#set seed for reproducibility
set.seed(456)

#generate baking times
baking_times <- rnorm(25, mean =45, sd = 2)

#one sample t-test (H0: mean = 46; H1 mean <46)
#Tests if the average is less than 46
t.test(baking_times,mu =46, alternative = "less")